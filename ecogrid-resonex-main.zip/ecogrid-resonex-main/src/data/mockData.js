// Simulates the JSON packets ESP32 will send over serial:
// {"p1":320,"p2":890,"p3":210,"pir":1,"mic":0,"batt":67,"solar":78,"wind":34}

// Thresholds for health classification
export const THRESHOLDS = {
  GREEN: 600,   // below this = healthy
  YELLOW: 1200, // below this = warning, above = critical
};

export const STRUCTURES = [
  { id: 'p1', name: 'Piezo 1', structure: 'Flyover — main span', gpio: 'GPIO 34' },
  { id: 'p2', name: 'Piezo 2', structure: 'Metro pillar — base', gpio: 'GPIO 35' },
  { id: 'p3', name: 'Piezo 3', structure: 'Streetlight pole',   gpio: 'GPIO 32' },
];

export function getStatus(value) {
  if (value < THRESHOLDS.GREEN)  return 'healthy';
  if (value < THRESHOLDS.YELLOW) return 'warning';
  return 'critical';
}

export function getHealthScore(readings) {
  // Average across all 3 sensors, normalised to 0-100
  const avg = readings.reduce((a, b) => a + b, 0) / readings.length;
  const score = Math.max(0, Math.round(100 - (avg / 4096) * 100));
  return score;
}

// Generates one realistic sensor packet
let _batt = 67;
let _time = 0;
let _anomalyTimer = 0;

export function generatePacket() {
  _time++;
  _anomalyTimer++;

  // Occasionally spike piezo 2 to simulate a warning event (every ~30 ticks)
  const spike = _anomalyTimer > 28 && _anomalyTimer < 32;
  if (_anomalyTimer > 35) _anomalyTimer = 0;

  const p1 = Math.round(200 + Math.random() * 300 + Math.sin(_time * 0.3) * 80);
  const p2 = spike
    ? Math.round(1000 + Math.random() * 500)
    : Math.round(150 + Math.random() * 250 + Math.sin(_time * 0.5) * 60);
  const p3 = Math.round(180 + Math.random() * 200 + Math.sin(_time * 0.2) * 50);

  const pir = Math.random() > 0.85 ? 1 : 0;
  const mic = Math.random() > 0.97 ? 1 : 0; // rare emergency event

  // Battery drains slowly, charges during day
  _batt = Math.min(100, Math.max(10, _batt + (Math.random() > 0.5 ? 0.1 : -0.05)));

  const solar = Math.round(60 + Math.random() * 30);
  const wind  = Math.round(20 + Math.random() * 40);

  return { p1, p2, p3, pir, mic, batt: Math.round(_batt), solar, wind, ts: Date.now() };
}

// Generates initial history (last 30 readings per sensor)
export function generateHistory(count = 30) {
  const hist = { p1: [], p2: [], p3: [], time: [] };
  for (let i = 0; i < count; i++) {
    const pkt = generatePacket();
    hist.p1.push(pkt.p1);
    hist.p2.push(pkt.p2);
    hist.p3.push(pkt.p3);
    hist.time.push(new Date(Date.now() - (count - i) * 2000).toLocaleTimeString());
  }
  return hist;
}