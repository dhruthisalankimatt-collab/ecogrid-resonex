import { useState, useEffect, useCallback, useRef } from 'react';
import TopBar from './components/TopBar';
import MetricCards from './components/MetricCards';
import StructuralPanel from './components/VibrationChart';
import SafetyPanel from './components/SafetyPanel';
import EnergyPanel from './components/EnergyPanel';
import AlertsFeed from './components/AlertsFeed';
import { generatePacket, generateHistory, getStatus, getHealthScore } from './data/mockData';

const MAX_HISTORY = 30;
const MAX_ALERTS  = 50;

function addAlert(setAlerts, message, type = 'info') {
  const time = new Date().toLocaleTimeString();
  setAlerts(prev => [...prev.slice(-MAX_ALERTS + 1), { message, type, time }]);
}

export default function App() {
  const [packet,       setPacket]       = useState(generatePacket());
  const [history,      setHistory]      = useState(generateHistory(MAX_HISTORY));
  const [alerts,       setAlerts]       = useState([
    { message: 'System initialised — simulation mode active', type: 'info', time: new Date().toLocaleTimeString() },
    { message: 'All 3 structural sensors online', type: 'ok', time: new Date().toLocaleTimeString() },
  ]);
  const [motionCount,  setMotionCount]  = useState(0);
  const [sosCount,     setSosCount]     = useState(0);
  const [isLive,       setIsLive]       = useState(false);
  const prevStatus = useRef({ p1: 'healthy', p2: 'healthy', p3: 'healthy' });

  // Simulation tick — every 2 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const pkt = generatePacket();
      setPacket(pkt);

      setHistory(prev => {
        const t = new Date().toLocaleTimeString();
        return {
          p1:   [...prev.p1.slice(-MAX_HISTORY + 1),   pkt.p1],
          p2:   [...prev.p2.slice(-MAX_HISTORY + 1),   pkt.p2],
          p3:   [...prev.p3.slice(-MAX_HISTORY + 1),   pkt.p3],
          time: [...prev.time.slice(-MAX_HISTORY + 1), t],
        };
      });

      // Structural status change alerts
      const names = { p1: 'Piezo 1 (Flyover)', p2: 'Piezo 2 (Metro pillar)', p3: 'Piezo 3 (Streetlight)' };
      ['p1', 'p2', 'p3'].forEach(key => {
        const newStatus = getStatus(pkt[key]);
        if (newStatus !== prevStatus.current[key]) {
          const typeMap = { healthy: 'ok', warning: 'warning', critical: 'critical' };
          addAlert(setAlerts,
            `${names[key]} status changed: ${prevStatus.current[key].toUpperCase()} → ${newStatus.toUpperCase()} (ADC: ${pkt[key]})`,
            typeMap[newStatus]
          );
          prevStatus.current[key] = newStatus;
        }
      });

      // PIR event
      if (pkt.pir === 1) {
        setMotionCount(c => c + 1);
        addAlert(setAlerts, 'PIR motion detected — streetlight switched to BRIGHT mode', 'info');
      }

      // Emergency event
      if (pkt.mic === 1) {
        setSosCount(c => c + 1);
        addAlert(setAlerts, '🚨 EMERGENCY: Acoustic distress event — SOS LED activated!', 'emergency');
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // WebSerial connect (for Monday when hardware arrives)
  const handleConnect = useCallback(async () => {
    if (!('serial' in navigator)) {
      alert('WebSerial not supported. Use Chrome or Edge browser.');
      return;
    }
    try {
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
      setIsLive(true);
      addAlert(setAlerts, 'ESP32 connected via WebSerial — live data active', 'ok');

      const reader = port.readable.getReader();
      let buffer = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += new TextDecoder().decode(value);
        const lines = buffer.split('\n');
        buffer = lines.pop();
        for (const line of lines) {
          try {
            const livePkt = JSON.parse(line.trim());
            setPacket(livePkt);
            setHistory(prev => {
              const t = new Date().toLocaleTimeString();
              return {
                p1:   [...prev.p1.slice(-MAX_HISTORY + 1),   livePkt.p1 ?? 0],
                p2:   [...prev.p2.slice(-MAX_HISTORY + 1),   livePkt.p2 ?? 0],
                p3:   [...prev.p3.slice(-MAX_HISTORY + 1),   livePkt.p3 ?? 0],
                time: [...prev.time.slice(-MAX_HISTORY + 1), t],
              };
            });
          } catch {}
        }
      }
    } catch (e) {
      console.error(e);
      addAlert(setAlerts, 'Serial connection failed — staying in simulation mode', 'warning');
    }
  }, []);

  const healthScore = getHealthScore([packet.p1, packet.p2, packet.p3]);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <TopBar isLive={isLive} onConnect={handleConnect} packet={packet} />

      <div style={{ padding: '20px 24px', maxWidth: 1200, margin: '0 auto' }}>
        {/* GPS bar */}
        <div style={{
          marginBottom: 16, padding: '8px 14px', borderRadius: 8,
          background: 'var(--bg2)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', gap: 10, fontSize: 11,
          color: 'var(--text3)',
        }}>
          <span style={{ color: 'var(--accent)' }}>📍</span>
          <span>12.9716° N, 77.5946° E · DSATM Campus, Bengaluru</span>
          <span style={{
            marginLeft: 8, padding: '1px 7px', borderRadius: 10,
            background: 'var(--green-dim)', color: 'var(--green)',
            border: '1px solid var(--green)', fontSize: 10,
          }}>GPS LOCK ✓</span>
          <span style={{ marginLeft: 'auto', fontFamily: 'JetBrains Mono' }}>
            {isLive ? '🔴 LIVE · ESP32' : '🟡 SIM · Dummy data'}
          </span>
        </div>

        {/* Metric cards */}
        <div style={{ marginBottom: 16 }}>
          <MetricCards
            packet={packet}
            healthScore={healthScore}
            motionCount={motionCount}
            sosCount={sosCount}
          />
        </div>

        {/* Main grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <StructuralPanel packet={packet} history={history} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <SafetyPanel packet={packet} />
            <EnergyPanel packet={packet} />
          </div>
        </div>

        {/* Full width alerts */}
        <AlertsFeed alerts={alerts} />

        {/* Footer */}
        <div style={{ marginTop: 16, textAlign: 'center', fontSize: 11, color: 'var(--text3)' }}>
          RESONEX-GRID · Team Visionary Loop · DSATM · EduGrid Hackathon 2026
        </div>
      </div>
    </div>
  );
}