import { Eye, Mic, Lightbulb, Siren, PersonStanding } from 'lucide-react';

function SafetyRow({ icon, label, sublabel, active, color, blink }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 0', borderBottom: '1px solid var(--border)',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 8,
        background: active ? `${color}20` : 'var(--bg3)',
        border: `1px solid ${active ? color + '40' : 'var(--border)'}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: active ? color : 'var(--text3)',
        flexShrink: 0,
      }}>
        <span className={active && blink ? 'pulse' : ''}>{icon}</span>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 500 }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 1 }}>{sublabel}</div>
      </div>
      <div style={{
        width: 8, height: 8, borderRadius: '50%',
        background: active ? color : 'var(--bg3)',
        border: `1px solid ${active ? color : 'var(--border2)'}`,
        boxShadow: active ? `0 0 6px ${color}` : 'none',
      }} className={active && blink ? 'pulse' : ''} />
    </div>
  );
}

export default function SafetyPanel({ packet }) {
  const pirActive = packet?.pir === 1;
  const micActive = packet?.mic === 1;
  const streetBright = pirActive;
  const sosActive = micActive;

  return (
    <div style={{
      background: 'var(--bg2)', border: `1px solid ${sosActive ? 'var(--red)' : 'var(--border)'}`,
      borderRadius: 12, padding: 20,
      boxShadow: sosActive ? '0 0 20px rgba(239,68,68,0.15)' : 'none',
      transition: 'all 0.3s',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8, color: 'var(--text2)' }}>
          Smart guardian
        </span>
        {sosActive && (
          <span style={{
            fontSize: 11, fontWeight: 700, letterSpacing: 1,
            padding: '3px 10px', borderRadius: 4,
            background: 'var(--red-dim)', color: 'var(--red)',
            border: '1px solid var(--red)', animation: 'pulse 1s infinite',
          }}>⚠ SOS ACTIVE</span>
        )}
      </div>

      <div>
        <SafetyRow
          icon={<PersonStanding size={16} />}
          label="PIR motion sensor"
          sublabel={pirActive ? 'Motion detected — streetlight bright' : 'No motion — standby'}
          active={pirActive}
          color="var(--blue)"
        />
        <SafetyRow
          icon={<Lightbulb size={16} />}
          label="Streetlight"
          sublabel={streetBright ? 'BRIGHT mode (GPIO 33, 220Ω)' : 'DIM mode (GPIO 15, 1kΩ)'}
          active={true}
          color={streetBright ? 'var(--cyan)' : 'var(--text3)'}
        />
        <SafetyRow
          icon={<Mic size={16} />}
          label="Acoustic monitor"
          sublabel={micActive ? '🚨 Distress event detected!' : 'Monitoring — no events'}
          active={micActive}
          color="var(--yellow)"
          blink
        />
        <SafetyRow
          icon={<Siren size={16} />}
          label="SOS LED (GPIO 19)"
          sublabel={sosActive ? 'FLASHING — emergency alert active' : 'Standby — ready to trigger'}
          active={sosActive}
          color="var(--red)"
          blink
        />
      </div>

      <div style={{
        marginTop: 12, padding: '8px 12px', borderRadius: 8,
        background: 'var(--bg3)', border: '1px solid var(--border)',
        fontSize: 11, color: 'var(--text3)',
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        <Eye size={12} />
        No motion → Blue LED dim · Motion → Blue LED bright · Distress → Blue OFF, Red SOS flashes
      </div>
    </div>
  );
}