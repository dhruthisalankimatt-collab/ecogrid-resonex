import { Activity, Wifi, Battery, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function TopBar({ isLive, onConnect, packet }) {
  const [time, setTime] = useState(new Date().toLocaleTimeString());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 24px', borderBottom: '1px solid var(--border)',
      background: 'var(--bg2)', position: 'sticky', top: 0, zIndex: 100,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 8, height: 8, borderRadius: '50%',
            background: 'var(--accent)',
            boxShadow: '0 0 8px var(--accent)',
          }} className={isLive ? 'pulse' : ''} />
          <span style={{ fontSize: 16, fontWeight: 600, letterSpacing: 1 }}>
            ECOGRID<span style={{ color: 'var(--accent)' }}>-RESONEX</span>
          </span>
        </div>
        <span style={{
          fontSize: 11, color: 'var(--text3)', fontFamily: 'JetBrains Mono',
          background: 'var(--bg3)', padding: '2px 8px', borderRadius: 4,
          border: '1px solid var(--border)',
        }}>NODE · RG-001 · DSATM</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text2)' }}>
          <Clock size={13} />
          <span className="mono">{time}</span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text2)' }}>
          <Battery size={13} />
          <span className="mono">{packet?.batt ?? '--'}%</span>
        </div>

        <button
          onClick={onConnect}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '5px 12px', borderRadius: 6, fontSize: 12, fontWeight: 500,
            cursor: 'pointer', border: '1px solid',
            borderColor: isLive ? 'var(--green)' : 'var(--border2)',
            background: isLive ? 'var(--green-dim)' : 'var(--bg3)',
            color: isLive ? 'var(--green)' : 'var(--text2)',
            fontFamily: 'Space Grotesk',
          }}
        >
          {isLive
            ? <><Activity size={13} /> Live</>
            : <><Wifi size={13} /> Connect ESP32</>
          }
        </button>
      </div>
    </div>
  );
}