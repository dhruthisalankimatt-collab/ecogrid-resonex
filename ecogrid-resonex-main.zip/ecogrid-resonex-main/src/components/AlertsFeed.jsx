import { useEffect, useRef } from 'react';

const TYPE_CONFIG = {
  warning:   { color: 'var(--yellow)', bg: 'var(--yellow-dim)', label: 'WARN' },
  critical:  { color: 'var(--red)',    bg: 'var(--red-dim)',    label: 'CRIT' },
  info:      { color: 'var(--blue)',   bg: 'var(--blue-dim)',   label: 'INFO' },
  ok:        { color: 'var(--green)',  bg: 'var(--green-dim)',  label: 'OK'   },
  emergency: { color: 'var(--red)',    bg: 'var(--red-dim)',    label: 'SOS'  },
};

export default function AlertsFeed({ alerts }) {
  const bottomRef = useRef(null);
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [alerts.length]);

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 12, padding: 20, display: 'flex', flexDirection: 'column',
    }}>
      <div style={{ marginBottom: 12 }}>
        <span style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8, color: 'var(--text2)' }}>
          Event log
        </span>
        <span style={{ fontSize: 11, color: 'var(--text3)', marginLeft: 8 }}>
          {alerts.length} events
        </span>
      </div>

      <div style={{ overflowY: 'auto', maxHeight: 240, display: 'flex', flexDirection: 'column', gap: 4 }}>
        {alerts.length === 0 && (
          <div style={{ fontSize: 12, color: 'var(--text3)', padding: '20px 0', textAlign: 'center' }}>
            No events yet
          </div>
        )}
        {alerts.map((a, i) => {
          const cfg = TYPE_CONFIG[a.type] || TYPE_CONFIG.info;
          return (
            <div key={i} className="slide-in" style={{
              display: 'flex', alignItems: 'flex-start', gap: 10,
              padding: '7px 10px', borderRadius: 7,
              background: cfg.bg, border: `1px solid ${cfg.color}25`,
            }}>
              <span style={{
                fontSize: 9, fontWeight: 700, letterSpacing: 1, flexShrink: 0, marginTop: 2,
                padding: '2px 5px', borderRadius: 3,
                background: cfg.color, color: '#000',
              }}>{cfg.label}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12 }}>{a.message}</div>
                <div style={{ fontSize: 10, color: 'var(--text3)', marginTop: 2, fontFamily: 'JetBrains Mono' }}>
                  {a.time}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}