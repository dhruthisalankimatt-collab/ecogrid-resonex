import { Sun, Wind, BatteryCharging } from 'lucide-react';

function EnergyBar({ icon, label, value, color, unit = '%' }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text2)', fontSize: 12 }}>
          <span style={{ color }}>{icon}</span>
          {label}
        </div>
        <span style={{ fontFamily: 'JetBrains Mono', fontSize: 13, fontWeight: 500, color }}>
          {value}{unit}
        </span>
      </div>
      <div style={{ height: 6, background: 'var(--bg3)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{
          height: '100%', borderRadius: 3,
          width: `${value}%`, background: color,
          transition: 'width 0.5s ease',
          boxShadow: `0 0 6px ${color}60`,
        }} />
      </div>
    </div>
  );
}

export default function EnergyPanel({ packet }) {
  const batt = packet?.batt ?? 0;
  const solar = packet?.solar ?? 0;
  const wind = packet?.wind ?? 0;
  const autonomy = Math.round((batt / 100) * 24);

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 12, padding: 20,
    }}>
      <div style={{ marginBottom: 16 }}>
        <span style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8, color: 'var(--text2)' }}>
          Energy harvest
        </span>
      </div>

      <EnergyBar icon={<Sun size={14} />}           label="Solar panel"    value={solar} color="var(--yellow)" />
      <EnergyBar icon={<Wind size={14} />}           label="Wind turbine"   value={wind}  color="var(--blue)" />
      <EnergyBar icon={<BatteryCharging size={14} />} label="Battery charge" value={batt}  color="var(--cyan)" />

      <div style={{
        marginTop: 4, padding: '10px 14px', borderRadius: 8,
        background: 'var(--accent-dim)', border: '1px solid rgba(0,212,170,0.2)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <span style={{ fontSize: 12, color: 'var(--text2)' }}>Estimated autonomy</span>
        <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--accent)', fontFamily: 'JetBrains Mono' }}>
          ~{autonomy}h off-grid
        </span>
      </div>

      <div style={{ marginTop: 10, fontSize: 10, color: 'var(--text3)' }}>
        Solar → Battery → ESP32 VIN · 100% off-grid operation
      </div>
    </div>
  );
}