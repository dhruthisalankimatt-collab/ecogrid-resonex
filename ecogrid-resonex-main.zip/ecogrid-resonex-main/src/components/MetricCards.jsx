import { ShieldCheck, BatteryCharging, Footprints, Siren } from 'lucide-react';

function Card({ icon, label, value, unit, color, sub }) {
  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 12, padding: '16px 20px',
      borderLeft: `3px solid ${color}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 12, color: 'var(--text2)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.8 }}>{label}</span>
        <span style={{ color, opacity: 0.8 }}>{icon}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{ fontSize: 28, fontWeight: 600, color, lineHeight: 1 }}>{value}</span>
        {unit && <span style={{ fontSize: 13, color: 'var(--text2)' }}>{unit}</span>}
      </div>
      {sub && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

export default function MetricCards({ packet, healthScore, motionCount, sosCount }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
      <Card
        icon={<ShieldCheck size={16} />}
        label="Structural index"
        value={healthScore}
        unit="%"
        color={healthScore > 80 ? 'var(--green)' : healthScore > 60 ? 'var(--yellow)' : 'var(--red)'}
        sub="Across all 3 sensor points"
      />
      <Card
        icon={<BatteryCharging size={16} />}
        label="Battery"
        value={packet?.batt ?? '--'}
        unit="%"
        color="var(--cyan)"
        sub="Solar charging active"
      />
      <Card
        icon={<Footprints size={16} />}
        label="Motion events"
        value={motionCount}
        color="var(--blue)"
        sub="PIR triggers today"
      />
      <Card
        icon={<Siren size={16} />}
        label="SOS alerts"
        value={sosCount}
        color={sosCount > 0 ? 'var(--red)' : 'var(--text3)'}
        sub={sosCount > 0 ? '⚠ Emergency active' : 'All clear'}
      />
    </div>
  );
}