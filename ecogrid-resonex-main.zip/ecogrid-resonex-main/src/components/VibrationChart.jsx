import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { THRESHOLDS, STRUCTURES, getStatus } from '../data/mockData';

const STATUS_COLOR = {
  healthy:  'var(--green)',
  warning:  'var(--yellow)',
  critical: 'var(--red)',
};

const STATUS_LABEL = {
  healthy:  'HEALTHY',
  warning:  'WARNING',
  critical: 'CRITICAL',
};

function MiniChart({ data, color, sensorKey }) {
  const chartData = data.time.map((t, i) => ({ t, v: data[sensorKey][i] }));
  return (
    <ResponsiveContainer width="100%" height={80}>
      <LineChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
        <XAxis dataKey="t" hide />
        <YAxis domain={[0, 4096]} hide />
        <Tooltip
          contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 6, fontSize: 11 }}
          itemStyle={{ color }}
          labelStyle={{ color: 'var(--text2)', fontSize: 10 }}
          formatter={(v) => [v, 'ADC']}
        />
        <ReferenceLine y={THRESHOLDS.GREEN}  stroke="var(--green)"  strokeDasharray="3 3" strokeWidth={0.8} />
        <ReferenceLine y={THRESHOLDS.YELLOW} stroke="var(--yellow)" strokeDasharray="3 3" strokeWidth={0.8} />
        <Line type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} dot={false} isAnimationActive={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default function StructuralPanel({ packet, history }) {
  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 12, padding: 20,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <span style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8, color: 'var(--text2)' }}>
          Structural sensors
        </span>
        <span style={{ fontSize: 11, color: 'var(--text3)', fontFamily: 'JetBrains Mono' }}>
          Threshold: {THRESHOLDS.GREEN} / {THRESHOLDS.YELLOW} ADC
        </span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {STRUCTURES.map((s) => {
          const val = packet?.[s.id] ?? 0;
          const status = getStatus(val);
          const color = STATUS_COLOR[status];
          return (
            <div key={s.id} style={{
              background: 'var(--bg3)', borderRadius: 10,
              border: `1px solid ${color}22`,
              padding: '12px 16px',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <div>
                  <span style={{ fontWeight: 600, fontSize: 13 }}>{s.name}</span>
                  <span style={{ fontSize: 11, color: 'var(--text3)', marginLeft: 8 }}>{s.structure}</span>
                  <span style={{ fontSize: 10, color: 'var(--text3)', marginLeft: 8, fontFamily: 'JetBrains Mono' }}>{s.gpio}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontFamily: 'JetBrains Mono', fontSize: 13, color: 'var(--text2)' }}>
                    {val} <span style={{ fontSize: 10, color: 'var(--text3)' }}>ADC</span>
                  </span>
                  <span style={{
                    fontSize: 10, fontWeight: 600, letterSpacing: 1,
                    padding: '3px 8px', borderRadius: 4,
                    background: `${color}20`, color,
                    border: `1px solid ${color}40`,
                  }}>{STATUS_LABEL[status]}</span>
                </div>
              </div>
              <MiniChart data={history} color={color} sensorKey={s.id} />
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: 10, fontSize: 10, color: 'var(--text3)' }}>
        Dashed lines = warning threshold (yellow) and healthy threshold (green) · 30-point rolling window
      </div>
    </div>
  );
}