# RESONEX-GRID Dashboard

## Setup (do this right now, no hardware needed)

### Step 1 — Install Node.js
Go to https://nodejs.org and download LTS version.

### Step 2 — Create Vite project
```bash
npm create vite@latest resonex-dashboard -- --template react
cd resonex-dashboard
```

### Step 3 — Copy these files
Replace everything in src/ with the files provided:
- src/index.css
- src/main.jsx
- src/App.jsx
- src/data/mockData.js
- src/components/TopBar.jsx
- src/components/MetricCards.jsx
- src/components/VibrationChart.jsx
- src/components/SafetyPanel.jsx
- src/components/EnergyPanel.jsx
- src/components/AlertsFeed.jsx

Also replace package.json and vite.config.js.

### Step 4 — Install dependencies
```bash
npm install
npm install recharts lucide-react
```

### Step 5 — Run it
```bash
npm run dev
```
Open http://localhost:5173 in Chrome.

---

## When hardware arrives (Monday)

1. Upload esp32_firmware.ino to ESP32-S3 via Arduino IDE
2. In Arduino IDE: Tools → Board → ESP32S3 Dev Module
3. Open Chrome (not Firefox — WebSerial only works in Chrome/Edge)
4. Open dashboard → click "Connect ESP32"
5. Select the COM port of your ESP32
6. Live data flows automatically

---

## Dashboard features
- Real-time vibration charts per sensor (Flyover, Metro pillar, Streetlight pole)
- Structural health score (0-100%)
- Smart guardian panel (PIR + acoustic + SOS)
- Energy harvest bars (Solar, Wind, Battery)
- Live event log with alerts
- WebSerial integration for live ESP32 data