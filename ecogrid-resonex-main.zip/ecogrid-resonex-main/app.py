import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

import serial
import threading
import pickle
import numpy as np
from collections import deque
from flask import Flask, send_from_directory
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

SERIAL_PORT = "COM5"
BAUD_RATE   = 115200

# ============================================================
# LOAD ML MODEL & SCALER
# ============================================================
with open("model.pkl", "rb") as f:
    MODEL = pickle.load(f)
with open("scaler.pkl", "rb") as f:
    SCALER = pickle.load(f)

print("ML Model loaded successfully")

# ============================================================
# SMOOTHING BUFFERS
# ============================================================
buf1 = deque(maxlen=10)
buf2 = deque(maxlen=10)
buf3 = deque(maxlen=10)

def smooth(buf, new_val):
    buf.append(new_val)
    return int(sum(buf) / len(buf))

# ============================================================
# SERIAL LINE PARSER
# ============================================================
def parse_line(line):
    data = {}
    for token in line.strip().split():
        if ":" in token:
            k, v = token.split(":", 1)
            data[k] = v.strip()
    return data

def safe_int(val, default=0):
    try:
        return int(val)
    except (ValueError, TypeError):
        return default

def safe_float(val, default=0.0):
    try:
        return float(val)
    except (ValueError, TypeError):
        return default

# ============================================================
# HEALTH & CRACK MAPPING
# ============================================================
def map_health(piezo_val):
    if piezo_val < 400:  return min(100, 95 - piezo_val // 20)
    if piezo_val < 700:  return max(50,  80 - (piezo_val - 400) // 10)
    if piezo_val < 1000: return max(25,  55 - (piezo_val - 700) // 12)
    return max(5, 30 - (piezo_val - 1000) // 20)

def map_crack(piezo_val):
    return min(100, max(0, (piezo_val - 200) // 25))

# ============================================================
# ML CLASSIFICATION
# ============================================================
def classify(p1, p2, p3):
    sample = np.array([[p1, p2, p3]])
    scaled = SCALER.transform(sample)
    pred   = int(MODEL.predict(scaled)[0])
    proba  = MODEL.predict_proba(scaled)[0]
    conf   = round(float(proba[pred]) * 100, 1)
    return pred, conf

# ============================================================
# SERIAL READER  (runs in background thread)
# ============================================================
def serial_reader():

    # Open serial port
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=2)
        print(f"Connected to {SERIAL_PORT}")
    except serial.SerialException as e:
        print(f"Serial connection error: {e}")
        print("Close Arduino IDE Serial Monitor first, then run again.")
        return

    while True:
        try:
            raw = ser.readline().decode("utf-8", errors="ignore").strip()
        except Exception as e:
            print(f"Read error: {e}")
            continue

        # Handle standalone MOTION line from ESP32
        if raw == "MOTION":
            socketio.emit("motion_alert", {"motion": True})
            continue

        # Must start with P1: to be a valid data line
        if not raw.startswith("P1:"):
            continue

        # Parse the line
        d = parse_line(raw)

        if not all(k in d for k in ("P1", "P2", "P3")):
            continue

        # Raw sensor values
        r1 = safe_int(d.get("P1"))
        r2 = safe_int(d.get("P2"))
        r3 = safe_int(d.get("P3"))

        # Smoothed values (rolling average of last 10)
        p1 = smooth(buf1, r1)
        p2 = smooth(buf2, r2)
        p3 = smooth(buf3, r3)

        dist   = safe_float(d.get("DIST"))
        motion = d.get("MOTION", "0") == "1"
        sos    = d.get("SOS",    "0") == "1"

        # Derived scores
        h1 = map_health(p1)
        h2 = map_health(p2)
        h3 = map_health(p3)

        c1 = map_crack(p1)
        c2 = map_crack(p2)
        c3 = map_crack(p3)

        # ML Classification
        pred, ai_conf = classify(p1, p2, p3)

        STATUS_MAP = {0: "NORMAL",    1: "WARNING",   2: "CRITICAL"}
        BADGE_TEXT = {0: "● HEALTHY", 1: "◉ WARNING", 2: "⚠ CRITICAL"}
        ml_status  = STATUS_MAP[pred]

        print(f"P1={p1} P2={p2} P3={p3} → {ml_status} ({ai_conf}% conf)")

        # ── KEY FIX: Send ML result back to ESP32 to light LEDs ──
        # ESP32 receives "ML:0,0,0" / "ML:1,1,1" / "ML:2,2,2"
        # and lights Green / Yellow / Red LEDs accordingly
        try:
            ml_cmd = f"ML:{pred},{pred},{pred}\n"
            ser.write(ml_cmd.encode())
        except Exception as e:
            print(f"Serial write error: {e}")

        # Emit UI updates to dashboard
        updates = [
            # Building (BLD-01) driven by P1
            ("ov-bld-piezo",  p1),
            ("ov-bld-health", h1),
            ("ov-bld-crack",  f"{c1}%"),
            ("s-piezo",       p1),
            ("s-health",      h1),
            ("s-crack",       f"{c1}%"),

            # Flyover (FLY-02) driven by P2
            ("ov-fly-piezo",  p2),
            ("ov-fly-health", h2),
            ("ov-fly-crack",  f"{c2}%"),

            # Streetlight (STL-03) driven by P3
            ("ov-stl-piezo",  p3),
            ("ov-stl-health", h3),

            # Guardian
            ("g-dist",        f"{dist:.1f} cm"),
            ("g-pir",         "MOTION!" if motion else "CLEAR"),
            ("g-acoustic",    f"{p1} raw"),

            # AI confidence
            ("ov-bld-ai",     f"{ai_conf}%"),
            ("s-conf",        f"{ai_conf}%"),
        ]

        for elem_id, val in updates:
            socketio.emit("update_ui", {"id": elem_id, "val": str(val)})

        # Confidence bar widths
        socketio.emit("update_ui", {"id": "ov-bld-conf", "val": str(ai_conf)})
        socketio.emit("update_ui", {"id": "s-conf-bar",  "val": str(ai_conf)})

        # Node badges
        socketio.emit("update_ui", {"id": "ov-bld-badge",  "val": BADGE_TEXT[pred]})
        socketio.emit("update_ui", {"id": "s-class-badge", "val": BADGE_TEXT[pred]})

        # Full ML result event
        socketio.emit("ml_result", {
            "pred":   pred,
            "status": ml_status,
            "conf":   ai_conf,
            "p1": p1, "p2": p2, "p3": p3,
            "h1": h1, "h2": h2, "h3": h3,
        })

        # Motion alert
        if motion:
            socketio.emit("motion_alert", {"motion": True})

        # SOS trigger
        if sos or p1 > 3000 or p2 > 3000:
            if p2 > 3000:
                cause = "Critical structural stress — Flyover Bridge"
            elif p1 > 3000:
                cause = "Critical structural stress — Building A"
            else:
                cause = "Acoustic + proximity trigger — Manual SOS"
            socketio.emit("sos_trigger", {"reason": cause})
            # Tell ESP32 to activate SOS LEDs + buzzer
            try:
                ser.write(b"SOS\n")
            except Exception as e:
                print(f"SOS write error: {e}")


# ============================================================
# FLASK ROUTES
# ============================================================
@app.route("/")
def index():
    return send_from_directory(".", "resonex_dashboard.html")

@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(".", filename)


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    t = threading.Thread(target=serial_reader, daemon=True)
    t.start()
    print("Server running at http://localhost:5000")
    socketio.run(app, host="0.0.0.0", port=5000, debug=False)